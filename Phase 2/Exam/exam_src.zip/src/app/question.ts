export class Question {
        constructor(public question:string,
                    public ans1:string,
                    public ans2:string,
                    public ans3:string,
                    public ans4:string,
                    public correctAns:string){}
    
}
